## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

googlesheets4::gs4_deauth()

## ----setup--------------------------------------------------------------------
library(sds100)

## -----------------------------------------------------------------------------
groups <- get_project_group_form_responses("1qW9R0rjOxfoj1XEuklFm-otr4RIV-zYVm5WouSWNYgY")
groups

## -----------------------------------------------------------------------------
dupe_groups <- duplicated_groups(groups)
dupe_groups

# Remove all duplicated groups
groups <- groups |>
  dplyr::filter(!group_name %in% dupe_groups)
groups

dupe_students <- find_students_in_multiple_groups(groups)
dupe_students

# find out which groups dvish@smith.edu belongs to
groups |>
  dplyr::filter(email_address == "dvish@smith.edu")

# After emailing with dvish@smith.edu, we find out they aren't in the Slow Starters anymore
# So we remove that entry
groups <- groups |>
  dplyr::filter(!(group_name == "Slow Starters" & email_address == "dvish@smith.edu"))
groups

## -----------------------------------------------------------------------------
groups |>
  group_names() |>
  dplyr::rename(groupname = group_name) |>
  write.csv(file = "~/groupnames.csv", row.names = FALSE)

## ----eval=FALSE---------------------------------------------------------------
#  # 51177 is the id number of our Moodle course
#  # It can be seen at the end of the URL when you open the Moodle page in your web browser
#  tab <- moodle_login(51177, username = "whopper", password = "CorrectHorseBatteryStaple", duo = "push")

## ----eval=FALSE---------------------------------------------------------------
#  # Log in "normally" through a Chrome/Chromium window
#  tab <- moodle_login(51177, graphical = TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  sesskey <- extract_moodle_session_key(tab)
#  auth_cookies <- extract_cookies(tab)

## ----eval=FALSE---------------------------------------------------------------
#  populate_groups(
#    course_id = 51177,
#    tab = tab,
#    groups = groups
#  )

## ----eval=FALSE---------------------------------------------------------------
#  post_rotation_schedules(
#    course_id = 51177,
#    tab = tab,
#    row_labels = c(
#      "Phase 2 (Data Description)",
#      "Phase 3 (Summarization)",
#      "Phase 4 (Visualization)",
#      "Phase 5 (Ethics & Impact)"
#    )
#  )

## ----eval=FALSE---------------------------------------------------------------
#  download_quiz_with_attachments(
#    item_id = 1233216,
#    tab = tab,
#    questions = 1, # only the first question has an attachment to download
#    output_dir = "~"
#    )

## ----eval=FALSE---------------------------------------------------------------
#  generate_data_reports("~/Submit your Project Data")

