## ----chunk_options, include = FALSE-------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE
)

## ----setup--------------------------------------------------------------------
library(sds100)
# change the seed if you want -- you can change it to anything
set.seed(1723)

## ----quiz_example-------------------------------------------------------------
sds100::write_moodle_quiz(
  pattern = "*.Rmd",  
  input_dir = system.file("questions", package = "sds100"),
  quiz_name = "practice_quiz",
  output_dir = tempdir()
)

## ----all_quizzes_example, eval=FALSE------------------------------------------
#  sds100::write_moodle_quiz(
#    pattern = "lab|token",
#    input_dir = "~/source/SDS-100/quizzes/",
#    quiz_name = "sds100_quiz",
#    output_dir = tempdir()
#  )

