library(parsermd)

test_that("as_document works", {
  # read in the lab template
  lab <- system.file("lab_template.qmd", package = "sds100")
  doc <- parse_rmd(lab)

  # check the header
  header <- rmd_select_header(doc)
  expect_s3_class(header, "rmd_ast")
  
  # initially, a YAML option is set to "no"
  old <- as_document(header)
  expect_true(any(grepl(" echo: no", old)))
  
  # but after we run our function, there shouldn't be any "no"s left
  class(header) <- c("qmd_yaml", class(header))
  expect_s3_class(header, "qmd_yaml")
  new <- as_document(header)
  expect_false(any(grepl(" echo: no", new)))
})

test_that("predicates work", {
  # read in the lab template
  lab <- system.file("lab_template.qmd", package = "sds100")
  doc <- parse_rmd(lab)

  h6 <- rmd_select(doc, has_section_h6())
  expect_length(rmd_select(h6, has_type("rmd_heading")), 3)
  
  expect_true(has_qmd_option_help(doc[[4]], document = "show"))
  expect_true(has_qmd_option_help(doc[[11]], document = "solutions"))
  expect_false(has_qmd_option_help(doc[[17]], document = "template"))
  expect_true(has_qmd_option_help(doc[[19]], document = "template"))
  
  expect_length(rmd_select(doc, has_qmd_option(document = "solutions")), 2)
  expect_length(rmd_select(doc, has_qmd_option(document = "show")), 1)
  expect_length(
    rmd_select(
      doc, 
      has_type("rmd_chunk") | has_qmd_option(document = "solutions")
    ),
    4
  )
  
  # strip_fences()
  expect_false(identical(rmd_strip_fences(h6), h6))
})

test_that("write functions work", {
  # read in the lab template
  lab <- system.file("lab_template.qmd", package = "sds100")
  doc <- parse_rmd(lab)
  
  # template lab has three chunks
  old_chunks <- rmd_select(doc, has_type("rmd_chunk"))
  expect_equal(length(old_chunks), 4)
  
  # template lab has two questions
  old_questions <- doc |>
    rmd_select(has_section_h6() & by_section("Question"))
  expect_length(
    rmd_select(old_questions, has_type("rmd_heading")), 
    2
  )
  
  # student template has two questions, but no solution chunks
  x <- write_lab_template(lab, template_dir = tempdir())
  stu <- parse_rmd(x)
  
  rmd_select_num_questions <- function(x) {
    x |>
      rmd_select(has_section_h6() & by_section("Question")) |>
      rmd_select(has_type("rmd_heading")) |>
      length()
  }
  
  expect_equal(rmd_select_num_questions(doc), 2)
  expect_equal(rmd_select_num_questions(stu), 2)
  expect_length(rmd_select(stu, has_qmd_option(document = "solutions")), 0)
  expect_length(rmd_select(stu, has_qmd_option(document = "template")), 1)
  expect_length(rmd_select(stu, has_qmd_option(document = "show")), 1)
  

  # student solutions has two questions, and three chunks
  x <- write_lab_solutions(lab, solutions_dir = tempdir())
  sol <- parse_rmd(x)

  expect_equal(rmd_select_num_questions(sol), 2)
  expect_length(rmd_select(sol, has_qmd_option(document = "solutions")), 2)
  expect_length(rmd_select(sol, has_qmd_option(document = "template")), 0)
  expect_length(rmd_select(sol, has_qmd_option(document = "show")), 1)
})


test_that("sanitization works", {
  # read in the lab template
  lab <- system.file("lab_template.qmd", package = "sds100")
  doc <- parse_rmd(lab)
  
  # strip out everything but "title"
  expect_length(
    rmd_sanitize_yaml(
      rmd_select_header(doc), 
      c("title")
    )[[1]], 
    1
  )
  
  # leave everything but execute
  expect_length(
    rmd_sanitize_yaml(
      rmd_select_header(doc), 
      c("title", "format", "editor", "knitr" , "bibliography")
    )[[1]], 
    4
  )
})
