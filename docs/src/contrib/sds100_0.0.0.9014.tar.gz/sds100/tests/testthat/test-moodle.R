test_that("moodle works", {
  skip("weird exams error?")
  # doesn't work as a test???
  x <- write_moodle_quiz(pattern = "mutate")
  expect_true(file.exists(x))
  
  y <- xml2::read_xml(x)
  expect_s3_class(y, "xml_document")
})

