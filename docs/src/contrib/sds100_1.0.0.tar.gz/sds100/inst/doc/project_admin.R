## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

googlesheets4::gs4_deauth()

## ----setup--------------------------------------------------------------------
library(sds100)

## -----------------------------------------------------------------------------
groups <- get_project_group_form_responses("1qW9R0rjOxfoj1XEuklFm-otr4RIV-zYVm5WouSWNYgY")
groups

## -----------------------------------------------------------------------------
dupe_groups <- duplicated_groups(groups)
dupe_groups

# Remove all duplicated groups
groups <- groups |>
  dplyr::filter(!group_name %in% dupe_groups)
groups

dupe_students <- find_students_in_multiple_groups(groups)
dupe_students

# find out which groups dvish@smith.edu belongs to
groups |>
  dplyr::filter(email_address == "dvish@smith.edu")

# After emailing with dvish@smith.edu, we find out they aren't in the Slow Starters anymore
# So we remove that entry
groups <- groups |>
  dplyr::filter(!(group_name == "Slow Starters" & email_address == "dvish@smith.edu"))
groups

## -----------------------------------------------------------------------------
groups |>
  group_names() |>
  dplyr::rename(groupname = group_name) |>
  write.csv(file = "~/groupnames.csv", row.names = FALSE)

## ----eval=FALSE---------------------------------------------------------------
#  tab <- moodle_login(
#    course_id = 51177,
#    username = "whopper",
#    password = "CorrectHorseBatteryStaple",
#    duo = "push"
#    )

## ----eval=FALSE---------------------------------------------------------------
#  populate_groups(
#    course_id = 51177,
#    tab = tab,
#    groups = groups
#  )

## ----eval=FALSE---------------------------------------------------------------
#  responses <- download_quiz_with_attachments(
#    item_id = 1233216,
#    tab = tab,
#    questions = 1, # Question 1 is expect to have the data set attached
#    output_dir = "~/Desktop/project_data_sets"
#  )

## -----------------------------------------------------------------------------
fs::dir_tree("~/Desktop/project_data_sets")

## ----eval=FALSE---------------------------------------------------------------
#  library(dplyr)
#  
#  responses |>
#    dplyr::mutate(
#      NA_vals = "NA",
#      decimal = ".",
#      encoding = "UTF-8"
#    ) |>
#    utils::write.csv(
#      file = file.path("~/Desktop/project_data_sets/Submit your Project Data (Round 1)", "responses.csv"),
#      row.names = FALSE
#      )

## ----eval=FALSE---------------------------------------------------------------
#  generate_data_reports(
#    quiz_export_dir = "~/Desktop/project_data_sets/Submit your Project Data (Round 1)",
#  )

## ----eval=FALSE---------------------------------------------------------------
#  generate_data_reports(
#    quiz_export_dir = "~/Desktop/project_data_sets/Submit your Project Data (Round 1)",
#    subset = responses$`Email address`[-c(1:2)]
#  )

## ----eval=FALSE---------------------------------------------------------------
#  tab <- post_rotation_schedules(
#    course_id = 51177,
#    tab = tab,
#    labels = c(
#      "Phase 2 (Data Description)",
#      "Phase 3 (Summarization)",
#      "Phase 4 (Visualization)",
#      "Phase 5 (Ethics & Impact)"
#    )
#  )

