## ----chunk_options, include = FALSE-------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE
)

## ----setup--------------------------------------------------------------------
library(sds100)

## ----full_questionbank_example, eval=FALSE------------------------------------
#  sds100::write_moodle_quiz(
#    pattern = "*.Rmd",
#    input_dir = here::here("quizzes"),
#    quiz_name = "sds100_quiz",
#    output_dir = here::here("quizzes")
#  )

## ----eval=FALSE---------------------------------------------------------------
#  tab <- moodle_login(
#    course_id = 51177,
#    username = "whopper",
#    password = "CorrectHorseBatteryStaple",
#    duo = "push"
#    )

## ----eval=FALSE---------------------------------------------------------------
#  # Log in "normally" through a Chrome/Chromium window
#  tab <- moodle_login(51177, graphical = TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  sesskey <- extract_moodle_session_key(tab)
#  auth_cookies <- extract_cookies(tab)

