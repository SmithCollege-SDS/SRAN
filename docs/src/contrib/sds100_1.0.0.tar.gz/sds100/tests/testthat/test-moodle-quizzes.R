testthat::test_that("Building Moodle quizzes works", {

  skip("I can't figure out how to locate the quizzes directory during R CMD Check. Maybe it's not possible?")
  testthat::expect_message(
    sds100::write_moodle_quiz(
      pattern = "di_token_googlesheets_",  
      input_dir = "../../quizzes/",
      quiz_name = "di_token_googlesheets",
      output_dir = tempdir()
      ),
    regexp = "Building quiz: di_token_googlesheets with 4 questions"
    )
  }
)
