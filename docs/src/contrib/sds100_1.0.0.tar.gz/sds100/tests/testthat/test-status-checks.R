test_that("version_string works", {
  
  expect_s3_class(version_string("4.4.1"), "version_string")

  expect_error(verion_string("5"))
  expect_error(verion_string(".4.5"))
  
  expected_object <- structure(
    list(string = "3.6.3", components = c("3", "6", "3")),
    class = "version_string"
  )
  expect_equal(version_string("3.6.3"), expected_object)
  
  expected_object <- structure(
    list(string = "4.0.0", components = c("4", "0", "0")),
    class = "version_string"
  )
  expect_equal(suppressWarnings(version_string("4.0")), expected_object)
  expect_warning(version_string("4.0"))
})

test_that("check_r_version works", {
  
  expect_true(check_r_version("2.0.0"))
  expect_true(check_r_version("2.0.0", "5.0.0"))
  expect_false(check_r_version("6.0.0"))
  expect_error(check_r_version("5.0.0", "2.0.0"))

})

test_that("relational operators for version strings work", {
  
  expect_true(version_string("5.0.0") > version_string("2.0.0"))
  expect_true(version_string("5.0.0") >= version_string("5.0.0"))
  expect_false(version_string("5.0.0") < version_string("2.0.0"))
  expect_false(version_string("5.0.0") <= version_string("2.0.0"))

  expect_true(version_string("5.0.0") <= version_string("5.0.0"))
  expect_true(version_string("4.0.0") <= version_string("5.0.0"))
  expect_false(version_string("5.0.0") > version_string("5.0.0"))
  expect_false(version_string("5.0.0") <= version_string("2.0.0"))

})
