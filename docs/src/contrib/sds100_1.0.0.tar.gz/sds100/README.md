# sds100 <img src='https://github.com/SmithCollege-SDS/sds/raw/master/man/figures/logo.png' align="right" height="120" />

<!-- badges: start -->
[![website](https://github.com/SmithCollege-SDS/sds100/workflows/website/badge.svg)](https://github.com/SmithCollege-SDS/sds100/actions)
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

Public facing page is live at: 

<https://smithcollege-sds.github.io/sds100/>

Install using from SRAN

```r
install.packages(
  "sds100",
  repos = c(options("repos"), "https://SmithCollege-SDS.github.io/SRAN/"),
  type = "source"
)
```