#' Solutions and templates helpers
#' @name helpers
#' @export
#' @importFrom parsermd as_document
#' @details The new as_document() method is motivated by what happens when 
#' converting the Rmd AST to text 
#' (i.e., a character vector with one element per line). 
#' When the \code{\link[parsermd]{as_document}} function converts the list 
#' serializes the YAML header in the AST into plain-text YAML using 
#' \code{\link[yaml]{as.yaml}}. 
#' But, \code{\link[yaml]{as.yaml}} converts any of R's logicals 
#' (i.e., \code{TRUE} and \code{FALSE} values) into `yes` and `no`. 
#' Older versions of RMarkdown are fine with encountering `yes` and `no` 
#' in the YAML header, and interpret them as logicals just fine. 
#' 
#' But Quarto's YAML parser is stricter, 
#' and requires true and false 
#' (and not True and False, or "true" and "false", etc.). 
#' The behavior of \code{\link[yaml]{as.yaml}} can be changed with a 
#' custom handler function for logical values, 
#' but since the \code{\link[yaml]{as.yaml}} function is invoked from 
#' within the `parsermd` namespace (specifically, from the 
#' `parser:::as_document.rmd_yaml_list()` function), 
#' we can't provide this handler directly. 
#' So instead, we provide a new \code{\link[parsermd]{as_document}} method for a 
#' class of list meant to be interpreted as a `.qmd` YAML header. 
#' We can add this class to the YAML header lists in the parsed Rmd AST, 
#' and get the desired behavior when converting the AST to text through 
#' a generic call to as.document(). (i.e., `TRUE` -> true).
#' @inheritParams parsermd::as_document
#' @examples 
#' \dontrun{
#' lab <- system.file("lab_template.qmd", package = "sds100")
#' header <- parse_lab_header(parsermd::parse_rmd(lab))
#' as_document(header)
#' class(header) <- c("qmd_yaml", class(header))
#' class(header)
#' as_document(header)
#' }

as_document.qmd_yaml <- function (x, ...) {
  handlers <- list(
    logical = function(x) {
      result <- ifelse(x, "true", "false")
      class(result) <- "verbatim"
      return(result)
    }
  )

  out <- x |>
    # why is it inserting two characters at the beginning of each line??
    yaml::as.yaml(handlers = handlers) |>
    stringr::str_split("\n") |>
    purrr::pluck(1)|>
    # remove trailing blank line introduced by string splitting on \n
    utils::head(-1) |>
    # remove weird characters
    stringr::str_sub(start = 3) 
  
  class(out) <- c("rmd_yaml", class(out))
  parsermd::as_document(out)
}

#' @rdname helpers
#' @export
#' @examples 
#' lab <- system.file("lab_template.qmd", package = "sds100")
#' if (require(parsermd)) {
#'   doc <- parsermd::parse_rmd(lab)
#'   rmd_select(doc, has_qmd_option(document = "solutions"))
#'   rmd_select(doc, has_qmd_option(document = "show"))
#'   rmd_select(doc, has_type("rmd_chunk") | has_qmd_option(document = "solutions"))
#' }

has_qmd_option <- function(...) {
  tidyselect::peek_data(fn = "has_option") |>
    purrr::map_lgl(has_qmd_option_help, ...) |>
    which()
}

#' @rdname helpers
#' @export
#' @examples 
#' lab <- system.file("lab_template.qmd", package = "sds100")
#' doc <- parsermd::parse_rmd(lab)
#' has_qmd_option_help(doc[[11]], document = "solutions")
#' has_qmd_option_help(doc[[11]], document = "template")

has_qmd_option_help <- function(x, ...) {
  opts = c(...)
  if (is.null(names(opts))) 
    names(opts) = rep("", length(opts))
  
  # for now, just grab the first option
  one_option <- opts[1]

  if (inherits(x, "rmd_chunk")) {
    content <- parsermd::as_document(x)
    # could theoretically vectorize this part....
    pattern <- paste0(
      "^[[:space:]]*?#\\|[[:space:]]*",
      names(one_option), ":[[:space:]]*",
      one_option,
      "$"
      )
    results <- grepl(pattern = pattern, content, ignore.case = TRUE)
    is_type <- any(results)
  } else {
    is_type <- FALSE
  }
  return(is_type)
}

#' @rdname helpers
#' @export

rmd_select_header <- function(x, ...) {
  # A thin wrapper around rmd_select() that copies the yaml header from an 
  # rmd_ast or rmd_tibble object.
  x |>
    parsermd::rmd_select(parsermd::has_type("rmd_yaml_list"))
}

#' @rdname helpers
#' @inheritParams parsermd::rmd_select
#' @export
#' @examples 
#' lab <- system.file("lab_template.qmd", package = "sds100")
#' doc <- parsermd::parse_rmd(lab)
#' parsermd::rmd_select(doc, has_section_h6())

has_section_h6 <- function(...) {
  sections <- tidyselect::peek_data(fn = "by_section") |>
    # weird bug workaround requires multiple levels???
    parsermd::rmd_node_sections(levels = 5:6) |>
    unlist() 
  
  # remove the h5's we don't care about
  sections <- sections[names(sections) != "sec_h5"]
  which(!is.na(sections))
}

#' @rdname helpers
#' @export

rmd_strip_fences <- function(x, ...) {

  # Fenced div's are used to target questions for styling in the main HTML.
  # This function allows you to strip the fenced divs from all markdown chunks in an parsermd::ast
  # object.
  # document need to be stripped out before the question text is placed in the 
  # student template document, otherwise students will see ::: question or
  # ::: {.question} everywhere, which will likely confuse more than help.
  
  # Define the `fence_remover()` function which actually returns a cleaned
  # character vector of markdown content
  fence_remover <- function(x) {
    content <- grep("^:{3,}.*$", x, value = TRUE, invert = TRUE)
    class(content) <- "rmd_markdown"
    return(content)
  }
  
  # Find all markdown nodes in the document tree
  is_markdown_node <- x |>
    purrr::map_chr(parsermd::rmd_node_type) == "rmd_markdown"
  
  # apply the fence_remover function over all markdown nodes, and insert the 
  # cleaned markdown content back into the document tree
  x[is_markdown_node] <- x[is_markdown_node] |>
    purrr::map(fence_remover)
  
  return(x)
}

#' @rdname helpers
#' @param yaml An `rmd_yaml_list` object
#' @param allowlist A character vector naming top-level YAML options to be 
#' kept in the header
#' @export
#' @examples 
#' \dontrun{
#' lab <- system.file("lab_template.qmd", package = "sds100")
#' yml <- rmd_select_header(parsermd::parse_rmd(lab))
#' rmd_sanitize_yaml(yml)
#' }

rmd_sanitize_yaml <- function(yaml, allowlist) {

  # Some of the YAML header options that are appropriate for rendering the main
  # lab HTML document are not appropriate to be in the solutions or template
  # documents. 
  # This allows you to define a set of top-level YAML options that should be 
  # preserved in the solutions or template document. All others are removed.
  opts <- yaml[[1]]
  
  sanitized_header_list <- opts[intersect(allowlist, names(opts))]
  class(sanitized_header_list) <- class(opts)
  yaml[[1]] <- sanitized_header_list
  yaml
}

#' @rdname helpers
#' @param chunk_type A scalar character vector identifying a type of code chunk, options are "solutions", "template", or "show". Treated as part of a regular expression, so multiple types can be specified by separating them with a |
#' @param chunk_opts A scalar character vector naming chunk options that should be removed from the code chunk. Treated as part of a regular expression, so multiple chunk options can be specified by separating them with a |
#' @export

strip_chunk_options <- function(x, chunk_type, chunk_opts) {
  
  strip <- function(chunk, pattern) {
    chunk$code <- stringr::str_subset(chunk$code, pattern, negate = TRUE)
    chunk
  }
  
  pattern <- paste0("^[[:space:]]*#\\|[[:space:]]*(",
                    chunk_opts,
                    ")[[:space:]]*:.*$"
                    )
  
  idx <- x |>
    purrr::map_lgl(has_qmd_option_help, document = chunk_type) |>
    which()
  
  x[idx] <- x[idx] |>
    purrr::map(strip, pattern = pattern)

  return(x)
}

#' @rdname helpers
#' @param ast A parsermd::rmd_ast object
#' @param label "root" name for the sections being numbered (e.g., "Question", "Exercise",
#'   "Problem", etc.) Converted to lower case internally, and compared against lowercased section
#'   headings.
#' @export
number_sections <- function(ast, label = "question") {
  
  is_question_header <- ast |>
    purrr::map_lgl(\(x) {
      # x$name might not exist, since only rmd_heading elements have names
      # isTRUE makes sure we get a boolean, not an empty character vector in that case
      class(x) == "rmd_heading" && isTRUE(tolower(x$name) == tolower(label))
    })
  
  n_question_headers <- sum(is_question_header)
  
  if (n_question_headers == 0) {
    return(ast)
  }
  
  new_header_text <- ast[is_question_header] |>
    purrr::map_chr("name") |>
    paste(seq_len(n_question_headers))
  
  ast[is_question_header] <- purrr::map2(
    ast[is_question_header],
    new_header_text,
    \(x, y) {
      x$name <- y
      return(x)
    }
  )
  
  return(ast)
}
  
#' Generate student template
#' @export
#' @param file path to a lab file
#' @param template_dir path to directory where you want to put the templates
#' @param lead_underscore prepend the filename with an underscore (to suppress 
#'      rendering)?
#' @param strip_fences Logical vector of length one. Controls whether pandoc fenced divs are removed
#'      from question text.
#' @param plaintext Logical vector of length one. Controls whether question text is converted to
#'   plain text. Default behavior is to preserve markdown.
#' @param ... currently ignored
#' 
#' @importFrom pandoc pandoc_convert
#' @examples 
#' \dontrun{
#' lab <- system.file("lab_template.qmd", package = "sds100")
#' write_lab_template(lab, lead_underscore = TRUE)
#' }

write_lab_template <- function(
    file, 
    template_dir = here::here("www", "templates"),
    strip_fences = TRUE,
    plaintext = FALSE,
    lead_underscore = FALSE,
    ...
  ) {
  
  # Parse the given file into an rmd_ast object
  main_doc <- parsermd::parse_rmd(file)
  
  questions <- main_doc |>
    parsermd::rmd_select(
      intersect(has_section_h6(), parsermd::by_section("Question")) | 
        has_qmd_option(document = "show")
    ) |>
    parsermd::rmd_select(
      !has_qmd_option(document = "solutions")
    ) |>
    parsermd::rmd_select(
      !has_qmd_option(document = "lab")
    )
  
  if (strip_fences) {
    # Remove all the fenced div ::: annotations within questions
    questions <- rmd_strip_fences(questions)    
  }

  ## Remove the eval, include, or echo options on any 'show' chunks. Leave 'template'
  ## chunks alone, since people might want to leave broken code chunks in as
  ## "code completion" exercises.
  
  questions <- questions |>
    strip_chunk_options(chunk_type = "show",
                        chunk_opts = "eval|include|echo"
                        )

  # Label the questions headers with numbers, making it easier to match a question from the 
  # template back to the lab HTML document
  questions <- questions |>
    number_sections()
  
  if (plaintext) {
    # Convert all markdown text to plain text using pandoc
    is_markdown_node <- parsermd::rmd_node_type(questions) == "rmd_markdown"
    questions[is_markdown_node] <- questions[is_markdown_node] |>
      purrr::map(\(x) { 
        x <- pandoc::pandoc_convert(text = x, to = "plain", version = "system")
        class(x) <- "rmd_markdown"
        return(x)
        }
      )
  }

  # copying the YAML header, so it can be edited to have preferred options
  template_header <- rmd_select_header(main_doc)
  # Keep only the listed YAML options in the header
  template_header <- rmd_sanitize_yaml(
    template_header,
    c("title", "format", "editor", "knitr")
  )
  # quarto doesn't do self-contained by default, so set that explicitly for students
  # note that this option was renamed from self-contained to embed-resources
  # at some point between quarto 1.0.38 and 1.2.269.
  template_header[[1]]$format <- list(html = list(`embed-resources` = TRUE))
  
  ## Combine the YAML header with the questions into one document
  class(template_header) <- c("qmd_yaml", class(template_header))
  template <- c(
    as_document(template_header),
    "",
    # padding = NULL stops blank lines between nodes
    as_document(questions, padding = if (plaintext) "" else NULL)
  )
  
  ## Create template file
  filename <- paste0(if(lead_underscore) "_" else "", basename(file))
  filepath <- file.path(template_dir, filename)
  writeLines(template, filepath)
  filepath
}

#' @rdname write_lab_template
#' @export
#' @param solutions_dir path to directory where you want to put the solutions
#' @return the path to the file written 
#' @examples 
#' \dontrun{
#' lab <- system.file("lab_template.qmd", package = "sds100")
#' write_lab_solutions(lab)
#' }

write_lab_solutions <- function(
    file, 
    solutions_dir = here::here("www", "solutions"), 
    ...
) {
  # Parse the given file into an rmd_ast object  
  main_doc <- parsermd::parse_rmd(file)

  # Extract all h6 nodes labeled as questions, and all nodes nested beneath them
  # Solutions should be nested under their respective question header
  # and this way we keep the question with the solutions, so the solutions aren't
  # "out of context".
  questions <- main_doc |>
    parsermd::rmd_select(
      (has_section_h6() & parsermd::by_section("Question")) | 
        has_qmd_option(document = "show|solutions")
    ) |>
    parsermd::rmd_select(
      !has_qmd_option(document = "template")
    )
  
  # Remove all the fenced div ::: annotations within questions
#  questions <- rmd_strip_fences(questions)
  
  ## Remove the eval, include, or echo options on any solutions chunks so we can
  ## control them at the global level. Solutions chunks should always be eval-ed,
  ## should never be echo-ed and the results should always be included.
  
  questions <- questions |>
    strip_chunk_options(chunk_type = "solutions|show",
                        chunk_opts = "eval|include|echo"
                        )

  # copying the YAML header, so it can be edited to have preferred options  
  solutions_header <- rmd_select_header(main_doc)
  
  # Keep only the listed YAML options in the header
  solutions_header <- rmd_sanitize_yaml(
    solutions_header,
    c("title", "format", "editor", "knitr" , "bibliography", "csl")
  )
  
  ## Set echo: false globally to make sure no R code is shown
  solutions_header[[1]]$execute$echo <- FALSE
  
  ## Combine the YAML header with the questions into one document
  class(solutions_header) <- c("qmd_yaml", class(solutions_header))
  solutions <- c(
    as_document(solutions_header),
    "",
    as_document(questions, padding = NULL) # padding = NULL stops blank lines between nodes
  )
  
  ## Create solutions file
  filename <- file.path(solutions_dir, basename(file))
  writeLines(solutions, filename)
  filename
}
