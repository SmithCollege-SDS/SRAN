library(xml2)

doc <- read_xml("docs/lab_01_setup.html", as_html = TRUE)

template_links <- xml_find_all(doc, '//main//a[contains(@href, "templates/")]')
xml_attr(template_links, "href") <- sub(".html", ".qmd", xml_attr(template_links, "href"))

write_html(doc, "docs/test.html")
