#' Export Moodle question bank in XML format
#' @param pattern regular expression that matches file names
#' @param input_dir path to the directory with all the questions in it
#' @param quiz_name name of the quiz you are creating
#' @param output_dir path to the directory where you want the quiz to go
#' @param ... arguments passed to \code{\link[exams]{exams2moodle}}
#' @seealso \code{\link[exams]{exams2moodle}}
#' @export
write_moodle_quiz <- function(
    pattern = "*.Rmd",
    input_dir,
    quiz_name,
    output_dir = tempdir(),
    ...
  ) {
  
  if (!fs::dir_exists(input_dir)) {
    stop("Input directory not found.")
  } else {
    message(paste0("Looking for questions in:\n", input_dir))
  }
  
  # clean out any HTML output in input_dir
  html_output <- input_dir |>
    fs::dir_ls(regexp = ".html$")
  message(paste("Deleting", length(html_output), "HTML files"))
  html_output |> 
    purrr::walk(fs::file_delete)

  # get the list of matching questions
  questions <- input_dir |>
    fs::dir_ls(regexp = pattern)
  
  if (!fs::dir_exists(output_dir)) {
    stop("Output directory not found.")
  } else {
    message(paste0("Going to write a file in:\n", output_dir))
  }

  message(
    paste("Building quiz:", quiz_name, "with", length(questions), "questions")
  )
  
  render_parent_env <- new.env(parent = parent.env(environment()))
  render_parent_env$input_dir <- normalizePath(input_dir)
  
  out <- exams::exams2moodle(
    file = questions,
    name = quiz_name,
    mchoice = list(shuffle = TRUE),
    schoice = list(shuffle = TRUE),
    dir = output_dir,
    envir = render_parent_env,
    ...
  )
  out_path <- fs::path(output_dir, paste0(quiz_name, ".xml"))
  if (fs::file_exists(out_path)) {
    return(out_path)
  } else {
    stop(paste("Output file", out_path, "not created"))
  }
}

get_page_body <- function(tab) {
  dom_nodeID <- tab$DOM$getDocument()$root$nodeId
  html_body <- tab$DOM$getOuterHTML(tab$DOM$querySelector(dom_nodeID, "body")$nodeId)$outerHTML
  rvest::read_html(html_body)
}

wait_for_element <- function(tab, elem, timeout = 10) {
  
  js <- paste("document.querySelector('", elem, "');")
  x <- tab$Runtime$evaluate(js)
  
  deadline <- Sys.time() + timeout
  while(is.null(x$result$className) && Sys.time() < deadline)  {
    x <- tab$Runtime$evaluate(js)
  }

  if (is.null(x$result$className)) {
    x <- NULL
  }
  return(invisible(x))
}

#' @title Open Moodle page in Chrome/Chromium
#' @description
#' This function launches a headless Chrome/Chromium instance, and opens the Moodle page identified
#' by the give course ID number in the web browser.
#' 
#' @param course_id A scalar numeric vector representing a Moodle course ID number.
#' @param graphical A scalar logical vector. If `FALSE`, a headless Chrome/Chromium instance is launched. If `FALSE`, a graphical Chrome/Chromium window is opened for the user to login to Moodle.
#' @param username A scalar character vector holding the username you log in to Moodle with
#' @param password A scalar character vector holding the password you log in to Moodle with
#' @param duo A scalar character vector identifying the Duo 2FA method you would like to use. Valid
#' methods are "push", "key", or "call".
#' @param timeout Scalar numeric vector. Describes the number of second to wait for network events (e.g., for a web page to load).
#' 
#' @return A [chromote::ChromoteSession()] object
#' 
#' @importFrom chromote ChromoteSession
#' @importFrom later run_now
#' @examples
#' \dontrun{
#' tab <- moodle_login(
#'   course_id = 51177,
#'   username = "whopper",
#'   password = "CorrectHorseBatteryStaple",
#'   duo = "push"
#' )
#' tab$view() # opens a debugging window showing the "headless" tab
#' }
#'
#' @export
moodle_login <- function(
    course_id, 
    graphical = FALSE, 
    username = NULL, 
    password = NULL, 
    duo = "default",
    timeout = 10
  ) {
  
  if (nchar(course_id) != 5 | !is.numeric(course_id)) {
    stop("`course_id` should be a five digit Moodle course ID")
  }
  
  if (graphical) {
    return(graphical_moodle_login(course_id))
  }
  
  # Don't remove, this is so `response` gets overwritten by <<- from inside promise callbacks later
  # Without the locally scoped variable, `response` gets assigned into the global env.
  response <- NULL
  
  # The page we're trying to end up at!
  # Trying to load this page should kick off the authorization process, and we'll respond to it
  course_url <- paste0("https://moodle.smith.edu/course/view.php?id=", course_id)

  tab <- ChromoteSession$new()
  
  page_load_promise <- tab$Page$loadEventFired(wait_ = FALSE)
  response_promise <- tab$Network$responseReceived(wait_ = FALSE)

  tab$Page$navigate(course_url, wait_ = FALSE)

  response_promise$then(function(value) {
    response <<- value
  })
  tab$wait_for(page_load_promise)

  # We might be already logged in, in which case we're done!
  if (response$response$url == course_url) {
    return(tab)
  }
  
  # If we don't end up at the course page, prepare for log in
  
  # Map argument names to "official" duo 2fa names
  duo_method_map <- c(
    "push" = "Duo push",
    "key" = "Security key",
    "call" = "Phone call"
    )
  if (!duo %in% names(duo_method_map)) {
    cli::cli_abort("{.str duo} is not a supported 2FA method.")
  }
  duo <- duo_method_map[duo]
  
  if (!startsWith(response$response$url, "https://login.smith.edu")) {
    stop("Reached an uncogonized endpoint (", response$response$url, "), login attempted cancelled.")
  }
  
  login_links <- get_page_body(tab) |>
    rvest::html_elements(".mx-auto a") |>
    rvest::html_attr("href") |>
    unlist()

  is_smith_login_link <- login_links |>
    purrr::map(\(x) httr::parse_url(x)$query$idpentityid) |>
    purrr::map_if(is.null, \(x) "") |>
    unlist() |>
    startsWith("https://login.smith.edu")

  page_load_promise <- tab$Page$loadEventFired(wait_ = FALSE)
  response_promise <- tab$Network$responseReceived(wait_ = FALSE)

  tab$Page$navigate(login_links[is_smith_login_link])

  response_promise$then(function(value) {
    response <<- value
  })

  tab$wait_for(page_load_promise)

  if (!startsWith(response$response$url, "https://login.smith.edu")) {
    stop("Reached an uncogonized endpoint (", response$response$url, "), login attempted cancelled.")
  }
  
  creds_accepted <- NULL
  check_login_response <- function(value) {
    
    is_login_page <- startsWith(
      x = value$response$url,
      "https://login.smith.edu/idp/profile/SAML2/Redirect/SSO"
    )
    if (is_login_page && value$response$status == 200 && value$type == "Document") {
      creds_accepted <<- FALSE
    }
    
    is_duo_page <- grepl("^https://.*\\.duosecurity.com.*", x = value$response$url)
    if (is_duo_page && value$response$status == 200 && value$type == "Document") {
      creds_accepted <<- TRUE
    }

  }
  
  cancel_cb <- tab$Network$responseReceived(wait_ = FALSE, callback_ = check_login_response)
  
  wait_for_element(tab, "#username")
  tab$Runtime$evaluate(paste0(
    "var input = document.getElementById('username');",
    "input.value = '", username, "';"
  ))
  wait_for_element(tab, "#password")
  tab$Runtime$evaluate(paste0(
    "var input = document.getElementById('password');",
    "input.value = '", password, "';"
  ))

  wait_for_element(tab, 'button[name="_eventId_proceed"]')
  tab$Runtime$evaluate("document.getElementsByName('_eventId_proceed')[0].click();")
  
  wait_until <- Sys.time() + timeout
  while(is.null(creds_accepted) && Sys.time() <= wait_until) {
    later::run_now(loop = tab$get_child_loop())
  }
  # dereference callback
  cancel_cb()
  
  if (is.null(creds_accepted)) {
    tab$close()
    stop("Timed out waiting for login response.")
  }

  if (!creds_accepted) {
    tab$close()
    stop("Username/password combination rejected.")
  }

  page_url <- tab$DOM$getDocument()$root$documentURL
  is_duo_prompt <- grepl("^https://.*\\.duosecurity\\.com/.*prompt\\?.*$", page_url)

  while (!(page_url == course_url || is_duo_prompt)) {
    Sys.sleep(.25)
    page_url <- tab$DOM$getDocument()$root$documentURL
    is_duo_prompt <- grepl("^https://.*\\.duosecurity\\.com/.*prompt\\?.*$", page_url)
  }

  if (page_url == course_url) {
    return(tab)
  }
  
  wait_for_element(tab, ".other-options-link")
  tab$Runtime$evaluate("document.getElementsByClassName('other-options-link')[0].click();")

  x <- wait_for_element(tab, ".all-auth-methods-list .method-label")
  labels <- get_page_body(tab) |>
    rvest::html_elements(".all-auth-methods-list .method-label") |>
    rvest::html_text() |>
    tolower()

  duo_method_index <- which(labels == tolower(duo)) - 1 # JS starts at 0

  wait_for_element(tab, ".auth-method-link")
  tab$Runtime$evaluate(
    paste0("document.getElementsByClassName('auth-method-link')[",
          duo_method_index,
          "].click();")
  )

  wait_for_element(tab, "div#auth-view-wrapper h1#header-text")

  twoFA_option <- get_page_body(tab) |>
    rvest::html_elements("h1") |>
    rvest::html_text()
  
  cli::cli_alert("{twoFA_option} to continue authentication")
  
  page_url <- tab$DOM$getDocument()$root$documentURL
  
  while (page_url != course_url) {
    
    # We don't want to use wait_for_element() here because if the browser is trusted, the
    # "do you want to trust?" menu won't ever show up. But the page URL doesn't change when it
    # shows up, so we can't tell apart the "still waiting for course page to load" situation from
    # the "do you want to trust?" situation based on URL. 
    # So we'll just poll the page for it as long as we're not yet on the course page.
    
    dont_trust <- tab$Runtime$evaluate("document.getElementById('dont-trust-browser-button');")
    if (!is.null(dont_trust$result$className) && dont_trust$result$className == "HTMLButtonElement") {
      tab$Runtime$evaluate("document.getElementById('dont-trust-browser-button').click();")
    }
    Sys.sleep(.25)
    page_url <- tab$DOM$getDocument()$root$documentURL
  }
  
  return(tab)
}

#' @importFrom processx process
#' @importFrom chromote find_chrome ChromeRemote Chromote
graphical_moodle_login <- function(course_id) {

  # Open a new web browser window configured to listen for incoming commands
  chrome_path <- chromote::find_chrome()
  p <- processx::process$new(
    command = chrome_path,
    args = c("--remote-debugging-address=0.0.0.0", "--remote-debugging-port=9222")
  )
  # Wait a bit for the debugging server to become ready for incoming connections
  Sys.sleep(2)
  
  # Attaching to an existing chrome window seems bugged in chromote 0.3 and 0.3.1 =/
  # The "process" method of the chromote object is never set, but it *is* used 
  # So we just monkeypatch a process object into the chromote object =/
  remote_browser <- chromote::ChromeRemote$new(host = "127.0.0.1", port = 9222)
  remote_browser[['.__enclos_env__']]$private$process <- p
  browser <- chromote::Chromote$new(browser = remote_browser)

  # Find the first tab in the web browser (there should only be 1 since it just opened)
  # and attach to it
  first_id <- function(browser) {
    ts <- browser$Target$getTargets()$targetInfos
    stopifnot(length(ts) > 0)
    browser$Target$getTargets()$targetInfos[[1]]$targetId
  }
  
  tab_id <- first_id(browser)
  tab <- browser$new_session(targetId = tab_id)

  # Go to the Moodle page for the course
  # If you're not logged in, this will redirect you to https://login.smith.edu/
  # where you can enter your credentials, do the duo two-factor, etc., as normal
  
  main_url <- paste0("https://moodle.smith.edu/course/view.php?id=", course_id)
  tab$Page$navigate(main_url)
  
  # Since the user may need to log in, wait until we actually get to the Moodle
  # page to continue
  while (tab$DOM$getDocument()$root$documentURL != main_url) {
    Sys.sleep(.5)
  }
  
  # Set up headless browser session for the use to take with them.
  headless_tab <- ChromoteSession$new()
  headless_tab$Network$setCookies(cookies = tab$Network$getCookies()$cookies)
  
  page_load_promise <- headless_tab$Page$loadEventFired(wait_ = FALSE)
  headless_tab$Page$navigate(main_url)
  headless_tab$wait_for(page_load_promise)
  
  # clean up graphical window
  tab$close()
  
  return(headless_tab)
}

#' @title Extract cookies from a Chrome browser tab
#' 
#' @param tab A [chromote::ChromoteSession()] object
#' 
#' @importFrom stats setNames
#' @importFrom httr set_cookies
#' 
#' @return an [httr] requests object with all fields NULL except the options$cookie field
#' @export
extract_cookies <- function(tab) {
  # Copy the cookies associated from the web browser associated with moodle.smith.edu
  # Which we can use to authenticate HTTP requests we're going to make in a moment
  cookies <- tab$Network$getCookies()
  httr_cookies <- stats::setNames(
    object = lapply(cookies[[1]], `[[`, "value"),
    nm = lapply(cookies[[1]], `[[`, "name")
    ) |>
    unlist() |>
    httr::set_cookies(.cookies = _)
  
  return(httr_cookies)
}

#' @title Extract the Moodle 'sesskey' string
#' @description
#' Whenever you log into Moodle, Moodle sets a "session key" that is expected to be included with POST and GET requests to the server. Given a Chromote session object, This function retrieves the current session key from the browser's JavaScript environment.
#' 
#' @param tab A [chromote::ChromoteSession()] object obtained via the [moodle_login()] function
#' 
#' @return A scalar character vector representing the Moodle session key
#' @export
extract_moodle_session_key <- function(tab) {
  tab$Runtime$evaluate("M.cfg.sesskey")$result$value
}

#' @title Create a new section on a Moodle page
#' 
#' @importFrom jsonlite fromJSON
#' @importFrom httr GET POST content content_type_json
#' @importFrom rvest html_text2 html_attr html_elements
#' 
#' @param course_id Scalar character vector giving the 5 digit ID number for a Moodle course
#' @param tab A [chromote::ChromoteSession()] object obtained via the [moodle_login()] function
#' @param section_name Scalar character vector giving the name of the new section
#' 
#' @export 
create_new_section <- function(course_id, tab, section_name) {
  
  sessionkey <- extract_moodle_session_key(tab)
  cookies <- extract_cookies(tab)
    
  # Get the HTML for the main Moodle course page
  URL <- paste0("https://moodle.smith.edu/course/view.php?id=", course_id)
  main_page <- httr::GET(URL, cookies)
  
  # Scrape the HTML to find the number and ID value for each section on the page
  # We need to find the number and ID for the *last* section, so we can add one below
  sections <- httr::content(main_page) |>
    rvest::html_elements("h3")
    
  section_names <- sections |>
    rvest::html_text2()
  
  section_numbers <- sections |>
    rvest::html_attr("data-number")
  
  section_moodle_ids <- sections |>
    rvest::html_attr("data-id")
  
  # Adding a new section is a two-step process. First, tell Moodle "Give me a new section"
  course_info <- httr::POST(
    paste0(
      "https://moodle.smith.edu/lib/ajax/service.php?sesskey=",
      sessionkey,
      "&info=core_courseformat_update_course"
    ),
    encode = "raw",
    content_type_json(),
    body = paste0(
      '[{"index":0,"methodname":"core_courseformat_update_course","args":{"action":"section_add","courseid":"',
      course_id,
      '","ids":[],"targetsectionid":',
      section_moodle_ids[length(section_moodle_ids)],
      "}}]"
    ),
    cookies
  )
  
  # After we tell Moodle "Give me a new section", it tells us the ID of this new section
  # and we update all the page information using it
  course_info_json <- httr::content(course_info)[[1]][["data"]] |>
    jsonlite::fromJSON(simplifyVector = FALSE)
  
  new_section_index <- course_info_json[[1]]$fields$numsections+1
  new_section_id <- course_info_json[[1]]$fields$sectionlist[new_section_index]
  
  updated_course_info <- httr::POST(
    paste0(
      "https://moodle.smith.edu/lib/ajax/service.php?sesskey=",
      sessionkey,
      "&info=core_course_edit_section"
    ),
    encode = "raw",
    content_type_json(),
    body = paste0(
      '[{"index":0,"methodname":"core_course_edit_section","args":{"id":"',
      new_section_id,
      '","action":"refresh","sectionreturn":0}}]'
    ),
    cookies
  )
  
  # Sections are just called "Topic 1", "Topic 2"... by default
  # So, we need to edit our new section title to have an informative name.
  # Which is again a two step process
  updated_course_info <- httr::POST(
    paste0(
      "https://moodle.smith.edu/lib/ajax/service.php?sesskey=",
      sessionkey,
      "&info=core_update_inplace_editable"
    ),
    encode = "raw",
    content_type_json(),
    body = paste0(
      '[{"index":0,"methodname":"core_update_inplace_editable","args":{"itemid":"',
      new_section_id,
      '","component":"format_topics","itemtype":"sectionnamenl","value":"',
      section_name,
      '"}}]'
    ),
    cookies
  )
  project_section_info <- httr::POST(
    paste0(
      "https://moodle.smith.edu/lib/ajax/service.php?sesskey=",
      sessionkey,
      "&info=core_courseformat_update_course"
    ),
    encode = "raw",
    content_type_json(),
    body = paste0(
      '[{"index":0,"methodname":"core_courseformat_update_course","args":{"action":"section_state","courseid":"',
      course_id,
      '","ids":[',
      new_section_id,
      "]}}]"
    ),
    cookies
  )
  return(project_section_info)
}

#' @title Project Rotation Schedules
#' @name rotation-schedules
#' @description
#' Create a data frame that holds the project rotation schedule for a group of students.
#' 
#' @param group_members A character vector where each element is the name of a student.
#' @param column_names A character vector where each element is the name of a data set. This vector should be sorted such that the first element corresponds to the data set contributed by the first student named in the `group_members` vector.
#' @param row_names A character vector where each element describes a phase in the project.
#' 
#' @importFrom dplyr lead
#' 
#' @examples
#' group1_schedule <- create_rotation_table(
#'   group_members = c("Reg I. Gigas", "Drake O. Vish", "Drag A. Pult"),
#'   column_names = c("Reg's Data", "Drake's Data", "Drag's Data"),
#'   row_names = c("Phase 2", "Phase 3", "Phase 4" , "Phase 5")
#' )
#' print(group1_schedule)
#' @export
create_rotation_table <- function(
    group_members,
    column_names,
    row_names
  ) {
  
  # Ensure that there are as many data sets as there are group members.
  if (length(group_members) != length(column_names)) {
    stop("Something is wrong. The number of data sets and team members do not match!")
  }
  
  # put the group members & column names in order of group member first names
  sort_order <- order(group_members)
  group_members <- group_members[sort_order]
  column_names <- column_names[sort_order]
  
  # get number of team members
  n_members <- length(group_members)
  
  # create rotation for labs
  rotations <- vector(mode = "list", length = n_members)
  rotations[[1]] <- group_members
  for (i in seq_len(length(row_names) - 1)) {
    rotations[[i + 1]] <- dplyr::lead(rotations[[i]], default = rotations[[i]][1])
  }

  # turn into table
  rotation_table <- t(as.data.frame(rotations))
  
  # rename rows/cols
  rownames(rotation_table) <- row_names
  colnames(rotation_table) <- column_names
  
  return(as.data.frame(rotation_table))
}

#' @describeIn rotation-schedules Create a verbal description of a group's project rotation table written in markdown
#' 
#' @param x a data frame representing a project rotation schedule, created using the [create_rotation_table] function.
#' 
#' @examples
#' write_rotation_schedule(group1_schedule)
#' 
#' @export
write_rotation_schedule <- function(x) {
  
  phase_templates <- list(
    phase2 = "**%s** will write the data description for %s, and send all the neccesary materials to %s when the data description is fully completed.",
    phase3 = "**%s** will pick up where %s left off in the prior phase, and summarize %s. They will send all the neccesary materials to %s when the summaries are fully complete.",
    phase4 = "**%s** will pick up where %s left off in the prior phase, and visualize %s. They will send all the neccesary materials to %s when the visualizations are fully complete.",
  phase5 = "**%s** will pick up where %s left off, and describe the ethical impacts of %s."
  )
  
  y <- textConnection(NULL, open = "w")
  
  for (phase in seq_len(nrow(x))) {
    
    cat(paste0("\n##### ", rownames(x)[phase], "\n\n"), file = y)
    
    for (dataset in seq_along(x)) {
      
      if (phase == 1) {
        
        insert <- sprintf(
          fmt = phase_templates[[phase]],
          x[phase, dataset],
          "their own data",
          x[phase + 1, dataset]
        ) 
        
      } else if (phase == 4)  {
        
        insert <- sprintf(
          fmt = phase_templates[[phase]],
          x[phase, dataset],
          x[phase - 1, dataset],
          "their own data"
        )
        
      } else {
        insert <- sprintf(
          fmt = phase_templates[[phase]],
          x[phase, dataset],
          x[phase - 1, dataset],
          colnames(x)[dataset],
          x[phase + 1, dataset])
      }

      cat(paste0("- ", insert, "\n"), file = y)
    
    }
    
  }
  
  rotation_schedule <- textConnectionValue(y)
  close(y)
  return(rotation_schedule)
}

#' Create the project rotation schedule for all groups, and post them to Moodle.
#' @inheritParams create_new_section
#' @param labels Titles for each phase of the project
#' 
#' @importFrom jsonlite fromJSON
#' @importFrom knitr knit2html
#' @importFrom rlang .data
#' @importFrom rvest html_element html_elements html_attrs 
#' @importFrom httr GET content
#' @importFrom dplyr bind_rows mutate rename inner_join group_by summarize n
#' 
#' @export
#' @examples
#' \dontrun{
#' tab <- moodle_login(48781)
#' post_rotation_schedules(48781, tab)
#' }
post_rotation_schedules <- function(course_id, tab, labels) {

  sessionkey <- extract_moodle_session_key(tab)
  cookies <- extract_cookies(tab)
  
  # Request the HTML for the Moodle page you would use to manage group membership.
  # The HTML of this page contains the "secret" Moodle group ID numbers.
  # They're not really secret per se, but they're basically only relevant to Moodle internals
  # so they're not visible anywhere
  resp1 <- httr::GET(
    url = paste0("https://moodle.smith.edu/group/index.php?id=", course_id),
    cookies
  )
  
  # Make a table of group names and group ID numbers
  group_ids <- httr::content(resp1) |>
    rvest::html_element("#groups") |>
    rvest::html_elements("option") |>
    rvest::html_attrs() |>
    dplyr::bind_rows() |>
    dplyr::mutate(title = sub(" \\([0-9]\\)$", "", .data$title)) |>
    dplyr::rename(group_idnumber = .data$value, group_name = .data$title)
  
  # Retrieve a table enumerating the members of each group
  resp2 <- httr::GET(
    url = paste0(
      "https://moodle.smith.edu/group/overview.php?dataformat=csv&id=",
      course_id,
      "&group=0&grouping=0"
    ),
    cookies
  )
  
  # Join the group ID's with the group membership we just retrieved
  # Then, create the project rotation schedule
  groups <- httr::content(resp2, show_col_types = FALSE) |>
    dplyr::inner_join(group_ids, by = c("Group" = "group_name")) |>
    dplyr::filter(.data[["Grouping"]] != "Not in a grouping") |>
    dplyr::group_by(.data$Group, .data$group_idnumber) |>
    dplyr::arrange(.data$`First name`) |>
    dplyr::summarize(
      x = list(
        create_rotation_table(
          paste(.data$`First name`, .data$`Last name`),
          paste0(.data$`First name`, "'s Data"),
          labels
        ) |>
        write_rotation_schedule()
      ),
      .groups = "drop"
    )
  
  # Format the rotation schedules as HTML tables, wrapping each groups' tables 
  # in a filter code conditional that means the table will only display if the
  # user is actually *in* that particular group
  rotation_tables <- textConnection(NULL, open = "w")
  instructor_rotation_tables <- textConnection(NULL, open = "w")
  
    for (i in 1:nrow(groups)) {
      
      cat(paste0("<p>{ifingroup ", groups$group_idnumber[i], "}</p>\n"),
          file = rotation_tables
          )
      
      cat(paste0("<p style='font-weight: bold;'>", groups$Group[i], "</p>\n"),
          file = rotation_tables
          )
      
      knitr::knit2html(text = groups$x[[i]], template = FALSE) |>
        cat(file = rotation_tables)
      
      cat(paste0("<p style='font-weight: bold;'>", groups$Group[i], "</p>\n"),
          file = instructor_rotation_tables
          )
      
      knitr::knit2html(text = groups$x[[i]], template = FALSE) |>
        cat(file = instructor_rotation_tables)
      
      cat("<p>{/ifingroup}</p>\n",
          file = rotation_tables
          )
    }
  
  project_section_info <- create_new_section(
    course_id = course_id,
    tab = tab,
    section_name = "Project Rotation Schedule"
    )
  
  # FINALLY, we upload the HTML tables we wrote earlier to the Moodle page
  project_section_info_json <- httr::content(project_section_info)[[1]][["data"]] |>
    jsonlite::fromJSON(simplifyVector = FALSE)
  
  .x <- httr::POST(
    'https://moodle.smith.edu/course/modedit.php',
     body = list(
      	"showdescription" = "1",
      	"completionunlocked" = "1",
      	"course" = course_id,
      	"coursemodule" = " ",
      	"section" = project_section_info_json[[1]]$fields$number,
      	"module" = "13",
      	"modulename" = "label",
      	"instance" = "",
      	"add" = "label",
      	"update" = "0",
      	"return" = "0",
      	"sr" = "0",
      	"sesskey" = sessionkey,
      	"_qf__mod_label_mod_form" = "1",
      	"mform_isexpanded_id_generalhdr" = "1",
      	"mform_isexpanded_id_modstandardelshdr" = "1",
      	"mform_isexpanded_id_availabilityconditionsheader" = "0",
      	"mform_isexpanded_id_activitycompletionheader" = "1",
      	"introeditor[text]" = paste(textConnectionValue(rotation_tables),
      	                            collapse = " "
      	                            ),
      	"name" = "Rotation Instructions",
      	"introeditor[format]" = "1",
      	"introeditor[itemid]" = "997065256",
      	"visible" = "1",
      	"cmidnumber" = "",
      	"lang" = "",
      	"availabilityconditionsjson" = "{\"op\":\"&\",\"c\":[],\"showc\":[]}",
      	"completion" = "0",
      	"submitbutton2" = "Save and return to course"
      	),
     cookies
     )

  .x <- httr::POST(
    'https://moodle.smith.edu/course/modedit.php',
     body = list(
      	"showdescription" = "1",
      	"completionunlocked" = "1",
      	"course" = course_id,
      	"coursemodule" = " ",
      	"section" = project_section_info_json[[1]]$fields$number,
      	"module" = "13",
      	"modulename" = "label",
      	"instance" = "",
      	"add" = "label",
      	"update" = "0",
      	"return" = "0",
      	"sr" = "0",
      	"sesskey" = sessionkey,
      	"_qf__mod_label_mod_form" = "1",
      	"mform_isexpanded_id_generalhdr" = "1",
      	"mform_isexpanded_id_modstandardelshdr" = "1",
      	"mform_isexpanded_id_availabilityconditionsheader" = "0",
      	"mform_isexpanded_id_activitycompletionheader" = "1",
      	"name" = "Rotation Instructions (Instructors Only)",
      	"introeditor[text]" = paste(textConnectionValue(instructor_rotation_tables),
      	                            collapse = " "
      	                            ),
      	"introeditor[format]" = "1",
      	"introeditor[itemid]" = "997065256",
      	"visible" = "1",
      	"cmidnumber" = "",
      	"lang" = "",
      	"availabilityconditionsjson" = "{\"op\":\"&\",\"c\":[],\"showc\":[]}",
      	"completion" = "0",
      	"submitbutton2" = "Save and return to course"
      	),
     cookies
     )
  
  # close the text connection handles
  close(rotation_tables) 
  close(instructor_rotation_tables)
  return(tab)
}

#' @title Retrieve Moodle student IDs
#' @description
#' Retrieve the internal ID number for each student in a Moodle course. This is *not* the same as 
#' the students ID number you might see when you download their grades, or on their ID card.
#' 
#' @inheritParams create_new_section
#' 
#' @importFrom xml2 as_list
#' @importFrom rvest read_html
#' 
#' @export
get_student_secret_ids <- function(course_id, tab) {

  sessionkey <- extract_moodle_session_key(tab)
  cookies <- extract_cookies(tab)
  
  participants_page <- httr::GET(
    paste0("https://moodle.smith.edu/user/index.php?id=", course_id),
     cookies
   )
  
  post_body <- paste0(
  '[{"index":0,
     "methodname":"core_table_get_dynamic_table_content",
     "args":{"component":"core_user",
             "handler":"participants",
             "uniqueid":"user-index-participants-', course_id, '",
             "sortdata":[{"sortby":"lastname","sortorder":4}],
             "jointype":2,
             "filters":{"courseid":{"name":"courseid",
                                    "jointype":1,
                                    "values":[', course_id, ']
                                    }
                        },
             "firstinitial":"",
             "lastinitial":"",
             "pagenumber":"1",
             "pagesize":"500",
             "hiddencolumns":[],
             "resetpreferences":false
            }
   }]'
  )
  
  resp <- httr::POST(
    paste0("https://moodle.smith.edu/lib/ajax/service.php?",
          "sesskey=", sessionkey,
          "&info=core_table_get_dynamic_table_content"
          ),
    encode = "raw",
    content_type_json(),
    body = post_body,
    cookies
    )
  
  student_rows <- httr::content(resp) |>
    {\(x){x[[1]]$data$html}}(x = _) |>
    rvest::read_html() |>
    rvest::html_elements("table#participants tr:not(.emptyrow)")
  
  student_ids <- student_rows |>
    rvest::html_elements("input") |>
    rvest::html_attr("id") |>
    sub("user", "", x = _)
  
  student_emails <- student_rows |>
    xml2::as_list() |>
    {\(x) {x[-1]}}() |>
    sapply(\(x) unlist(x[3], recursive = TRUE, use.names = FALSE))
  
  data.frame(
    student_id = student_ids[-1],
    student_email = student_emails
  )
    
}

#' @title Retrieve Moodle group IDs
#' @description
#' Retrieve the internal ID number for each group in a Moodle course
#' 
#' @inheritParams create_new_section
#' 
#' @importFrom dplyr bind_rows mutate rename
#' 
#' @export
get_group_ids <- function(course_id, tab) {
  
  cookies <- extract_cookies(tab)
  
  group_main_page <- httr::GET(
    paste0("https://moodle.smith.edu/group/index.php?id=", course_id),
    cookies
  )
  
  group_ids <- httr::content(group_main_page) |>
    rvest::html_element("#groups") |>
    rvest::html_elements("option") |>
    rvest::html_attrs() |>
    dplyr::bind_rows() |>
    dplyr::mutate(title = sub(" \\([0-9]\\)$", "", .data$title)) |>
    dplyr::rename(group_idnumber = .data[["value"]], group_name = .data[["title"]])
  
  return(group_ids)
}

#' @title Retrieve Moodle group IDs
#' @description
#' Populates Moodle groups with members based on correspondence between Moodle group name, and a 
#' "tidy" data frame describing the group each student is in.
#' 
#' @inheritParams create_new_section
#' @param groups A data frame containing the group names and emails of students in each group. The name of the column holding the emails is assumed to be `email_address`, and the name of the column holding the group names is assumed to be `group_name`.
#' @importFrom dplyr left_join semi_join
#' 
#' @export
populate_groups <- function(course_id, tab, groups) {

  sessionkey <- extract_moodle_session_key(tab)
  cookies <- extract_cookies(tab)
  
  group_ids <- get_group_ids(course_id, tab)
  student_ids <- get_student_secret_ids(course_id, tab)

  groups <- dplyr::left_join(
    groups,
    student_ids,
    by = c("email_address" = "student_email")
  )

  for (id in group_ids$group_idnumber) {
    
    x <- dplyr::semi_join(
      groups,
      dplyr::filter(group_ids, .data$group_idnumber == id),
      by = "group_name"
    )
    
    student_id_component <- paste("addselect%5B%5D",  x$student_ids,  sep = "=", collapse = "&")
    
    generic_body <- list(
      "sesskey" = sessionkey,
      "removeselect_searchtext" = "",
      "userselector_preserveselected" = "0",
      "userselector_autoselectunique" = "0",
      "userselector_searchanywhere" = "0",
      "add" = "%E2%97%84%C2%A0Add",
      "addselect_searchtext" = ""
    )
    
    students <- as.list(x$student_id)
    names(students) <- rep("addselect[]", length(students))
  
    resp <- httr::POST(
      paste0("https://moodle.smith.edu/group/members.php?group=", id),
      encode = "form",
      body = c(generic_body, students),
      cookies
    )
    
  }
  
  return(tab)

}

#' @title Retrieve course roster from Moodle
#' @description
#' Retrieve the course roster from Moodle. This roster includes all students, but not all course
#' participants (i.e., does not include TA's, instructors, administrators, etc.).
#' 
#' @inheritParams create_new_section
#' 
#' @importFrom xml2 url_escape
#' @importFrom httr content
#' 
#' @return A data frame with 4 columns (`first_name`, `last_name`, `id_number`, and `email_address`)
#' @export
get_course_roster <- function(course_id, tab) {
  
  sessionkey <- extract_moodle_session_key(tab)
  cookies <- extract_cookies(tab)
  
  export_page <- httr::GET(
    url = paste0("https://moodle.smith.edu/grade/export/txt/index.php?id=", course_id),
    cookies
  )
  
  grade_items <- httr::content(export_page) |>
    html_elements("#id_gradeitemscontainer .form-check-input") |>
    html_attr("name")
  
  body <- list(
    "mform_isexpanded_id_gradeitems" = "1",
    "checkbox_controller1" = "0",
    "mform_isexpanded_id_options" = "1",
    "id" = as.character(course_id),
    "sesskey" = sessionkey,
    "_qf__grade_export_form" = "1"
  )

  body <- c(
    body,
    setNames(object = rep(list("0"), length(grade_items)),
             nm = grade_items
             ),
    list(
      "export_feedback" = "0",
      "export_onlyactive" = "0",
      "export_onlyactive" = "1",
      "display[real]" = "0",
      "display[real]" = "1",
      "display[percentage]" = "0",
      "display[letter]" = "0",
      "decimals" = "2",
      "separator" = "comma",
      "submitbutton" = "Download"
    )    
  )

  raw_csv <- httr::POST(
    url = "https://moodle.smith.edu/grade/export/txt/export.php",
    httr::add_headers(Accept = "text/csv"),
    encode = "form",
    cookies,
    body = body
  )
  
  roster <- httr::content(
    raw_csv,
    type = "text/csv",
    show_col_types = FALSE,
    encoding = "UTF-8"
  )
  
  roster <- roster[c("First name", "Last name", "ID number", "Email address")]
  names(roster) <- c("first_name", "last_name", "id_number", "email_address")
  
  return(roster)
}

extract_attachment_filenames <- function(x) {
  # \u00A0 is non-breaking space =(
  regexpr("(?<=: ).*(?= \\([0-9KMGB\\.\u00A0]*\\)$)", text = x, perl = TRUE) |>
    regmatches(x = x,  m = _) |>
    replace(x, !is.na(x), values = _)
}

#' @title Download quiz responses including attached files
#' @description Downloads all completes responses to a Moodle quiz, along with any file attachments.
#'
#' @inheritParams post_rotation_schedules
#' @param item_id The ID number of the Moodle assignment/quiz. Can be found in the URL shown in the
#'   address bar when the assignment/quiz is opened in the web browser.
#' @param questions Vector of question numbers that are expected to have attachments
#' @param output_dir Path to the folder where responses/attachments retrieved from Moodle will be
#'   output. A folder matching the name of the quiz/assignment will be created in this folder, and
#'   all responses attachments will be placed within.
#'
#' @details Text responses for each finished attempted are stored in the responses.csv file Within
#'   `output_dir` a folder is created for each student, where the name of the folder corresponds to
#'   the student's email address. Each student's file attachments from the Moodle quiz are placed
#'   in the their respective folder.
#'   
#' @importFrom tidyselect everything
#' @importFrom rvest html_text
#' @importFrom httr write_disk
#' 
#' @export
download_quiz_with_attachments <- function(item_id, tab, questions, output_dir) {
  
  if (!dir.exists(output_dir)) {
    stop(output_dir, " does not exist")
  }
  
  p <- tab$Page$loadEventFired(wait_ = FALSE)
  tab$Page$navigate(
    paste0("https://moodle.smith.edu/mod/quiz/report.php?id=",
           item_id,
           "&mode=overview&onlygraded=1"
           ),
    wait_ = FALSE
    )
  tab$wait_for(p)
  
  sessionkey <- extract_moodle_session_key(tab)
  cookies <- extract_cookies(tab)

  request_body <- list(
    "id" = item_id,
    "mode" = "responses",
    "sesskey" = sessionkey,
    "_qf__quiz_responses_settings_form" = 1,
    "mform_isexpanded_id_preferencespage" = 1,
    "mform_isexpanded_id_preferencespage" = 1,
    "attempts" = "enrolled_with",
    "stateinprogress" = 0,
    "stateoverdue" = 0,
    "statefinished" = 0,
    "statefinished" = 1,
    "stateabandoned" = 0,
    "pagesize" = 500,
    "qtext" = 0,
    "resp" = 0,
    "resp" = 1,
    "right" = 0,
    "submitbutton" = "Show+report"
  )
  
  quiz_response_page <- httr::POST(
    "https://moodle.smith.edu/mod/quiz/report.php",
    encode = "form",
    body = request_body,
    cookies
  ) |>
  httr::content()
  
  quiz_title <- quiz_response_page |>
    html_element("#page-header h1") |>
    rvest::html_text()
  
  responses_table <- quiz_response_page |>
    rvest::html_element(css = "table#responses")
  
  responses <- responses_table |>
    rvest::html_table(na.strings = c("", "-")) |>
    dplyr::filter(!is.na(.data$`Select all`)) |>
    dplyr::select(-.data$`Select all`)
  
  names(responses) <- sub("Sort by.*", "", names(responses))
  
  incomplete_quiz_index <- responses |>
    dplyr::transmute(dplyr::across(tidyr::everything(), is.na)) |>
    rowSums() |>
    as.logical()
  
  # incomplete_quizzes <- responses[incomplete_quiz_index, ]

  responses <- responses |>
    dplyr::rename(Name = .data$`First name`) |>
    dplyr::mutate(
      Name = sub("Review attempt", "", .data$Name, fixed = TRUE)
    ) |>
    dplyr::mutate(
      dplyr::across(.cols = paste0("Response ", questions), .fns = extract_attachment_filenames)
    )

  root <- file.path(output_dir, quiz_title)
  if (!dir.exists(root)) {
    dir.create(root)
  }
  
  rows <- responses_table |>
    rvest::html_elements("tr:not(.emptyrow)")
  
  rows <- rows[-1] # drop header row
  # rows <- rows[!incomplete_quiz_index] # discard incomplete quizzes
  
  # Map question numbers to column indices in the Moodle table
  # -1 because Moodle starts the columns number index at 0
  column_indexes <- paste0(".c", questions - 1  + 5)
  
  for (c in seq_along(column_indexes)) {
    
    links_to_questions <- rows |>
        html_element(css = column_indexes[c]) |>
        html_element("a") |>
        html_attr("href")
    
    for (i in seq_along(links_to_questions)) {
      
      q <- httr::GET(url = links_to_questions[[i]], cookies) |>
        httr::content()
      
      question_state <- q |> 
        rvest::html_elements("div.state") |>
        rvest::html_text()
      
      if  (question_state == "Not answered") {
        message("Skipping ", i, " Question ", questions[c] - 1 + 5, " (Question not answered)")
        next
      }
      
      attachment_link <- q |> 
        html_elements("div.attachments a") |>
        html_attr("href")
      
      if (length(attachment_link) == 0) {
        message("Skipping ", i, " Question ", questions[c] - 1 + 5, " (No Attachment Found)")
        next
      }
      
      student_dir <- file.path(root, responses$`Email address`[i])
      if (!dir.exists(student_dir)) {
        dir.create(student_dir)
      }
      
      cli::cli_alert_info("Downloading responses for {responses$`Email address`[i]}")
      
      data_file <- httr::GET(
        attachment_link,
        cookies,
        httr::write_disk(
          file.path(student_dir, responses[[questions[c] - 1 + 5]][i]),
          overwrite = TRUE
          )
        )
    }
    
  }
  
  return(responses)
}

#' @title Generate reports about project data sets
#' @description
#' This function is intended to be used after using the [download_quiz_with_attachments()] function to 
#' export the results from the "Submit your Project Data" quiz. You can point this function at the
#' directory holding the export from this quiz, and it will write an overview report into each
#' student's folder. This report is useful in assessing whether there are any issues with the data
#' the student has proposed to use.
#' 
#' @param quiz_export_dir Folder containing output from the [download_quiz_with_attachments()] function. Is
#' expected to have the following structure:
#'└── `output_dir`
#'    ├── ssmith@smith.edu
#'    │   └── example.csv
#'    ├── whopper@smith.edu
#'    │   └── pokemon.csv
#'    ├── responses.xlsx
#' @param subset A character vector holding email addresses, identifies the students for whom a data
#' summary report should be generated. Default behavior is to generate a report for all students.
#' 
#' @importFrom quarto quarto_render
#' @importFrom utils read.csv
#' @details
#' The report generated for each student is based on the template found in
#' `system.file("data_set_report.qmd", package = "sds100")`. It uses [readr::read_delim()] to import
#' plain-text data files. `read_delim()` is quite good at guessing the delimeter and decimal marker,
#' but not perfect, and only if there are not character encoding problems. Unfortunately, there are
#' sometimes character encoding problems.
#' 
#' If a file cannot be parsed using UTF-8 encoding, you can manually specify the appropriate
#' encoding by adding a column named `encoding` to the `responses.csv` file. Fill the column with
#' the value `UTF-8`, *except* for the rows where you want to use a different encoding.
#' 
#' @returns If reports are generated successfully, returns `TRUE` invisibly.
#' @export
generate_data_reports <- function(quiz_export_dir, subset = NULL) {
  
  quiz_responses <- read.csv(file.path(quiz_export_dir, "responses.csv"), na.strings = "")
  
  if (!is.null(subset) && is.character(subset)) {
    quiz_responses <- quiz_responses[quiz_responses$Email.address %in% subset, ]
  }
  
  if (! nrow(quiz_responses) > 0) {
    stop("No quiz responses found. Are the student emails in your `subset` correct?")
  }

  if (!("NA_vals" %in% names(quiz_responses))) {
    quiz_responses$NA_vals <- "NA"
  }
  
  if (!("decimal" %in% names(quiz_responses))) {
    quiz_responses$decimal <- "."
  }
  
  if (!("encoding" %in% names(quiz_responses))) {
    quiz_responses$encoding <- "UTF-8"
  }
  
  tmp <- tempdir()
  copied <-file.copy(
    from = system.file("data_set_report.qmd", package = "sds100"),
    to = file.path(tmp, "data_set_report.qmd"),
    overwrite = TRUE
    )
  
  if (!copied) {
    stop("Could not copy ",
         system.file("data_set_report.qmd", package = "sds100"),
         " to ",
         file.path(tmp, "data_set_report.qmd")
         )
  }
  
  n_responses <- nrow(quiz_responses)
  
  for (i in seq_len(n_responses)) {
    
    student_resp <- quiz_responses[i, ]
    cat("Processing", student_resp$Email.address, "(", i, "/", n_responses, ")\n")
    
    quarto::quarto_render(
      file.path(tmp, "data_set_report.qmd"),
      execute_dir = tools::file_path_as_absolute(
        file.path(quiz_export_dir, student_resp$Email.address)
        ),
      execute_params = list(student_resp = student_resp)
    )
    
    file.copy(
      from = file.path(tmp, "data_set_report.html"),
      to = file.path(quiz_export_dir, student_resp$Email.address, paste0(student_resp$Name, ".html")),
      overwrite = TRUE
    )
  }
  
  unlink(file.path(tmp, "data_set_report.html"))
  unlink(file.path(tmp, "data_set_report.qmd"))
  return(invisible(TRUE))
}
