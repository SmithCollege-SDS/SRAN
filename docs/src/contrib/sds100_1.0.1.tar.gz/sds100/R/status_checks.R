# This file defines functions that check the status of the development environment
# These functions are intended primarily to be used in Lab 1, when students are installing
# software

#' @param x Scalar character vector describing a version of R. Should be
#'   specified in the Major.Minor.Patch format e.g., 3.6.3 or 4.4.1
new_version_string <- function(x) {

  components <- strsplit(x, ".", fixed = TRUE)[[1]]
  
  if (length(components) == 2) {
    patched <- paste(x, "0", sep = ".")
    warning(paste("Converting version", x, "(Major.Minor format) to", patched, "(Major.Minor.Path format)"))
    x <- paste(x, "0", sep = ".")
    components <- c(components, "0")
  }
  
  structure(
    list(string = x, components = components),
    class = "version_string"
  )

}

#' @param v a version string object
validate_version_string <- function(v) {
  
  if (length(v$components) != 3 || all(nchar(v$components) != 1)) {
    stop("Version string does not match expected format (Major.Minor.Patch)")
  }
  
  return(v)

}

#' @title Create a new version string object
#' @description
#' Creates a new version string object based on a character vector describing a version of R
#' 
#' @inheritParams new_version_string
#' @export
version_string <- function(x) {
  v <- new_version_string(x)
  v <- validate_version_string(v)
  return(v)
}


#' @param x A version string object
#' @param ... ignored, included for compatibility with print generic function
#' @export 
print.version_string <- function(x, ...) {
  print(paste("R version", x$string))
}

#' @description
#' Compares two version strings, and returns `TRUE` if the first version string is greater than or
#' equal to the second version string
#' @export
`>=.version_string` <- function(v1, v2) {

  major_version <- as.numeric(v1$components[1])
  minor_version <-  as.numeric(paste(v1$components[2:3], collapse = "."))
  
  min_major_version <- as.numeric(v2$components[1])
  min_minor_version <- as.numeric(paste(v2$components[2:3], collapse = "."))
  
  min_version_met <- 
    if (major_version > min_major_version) {
      TRUE
    } else if (major_version == min_major_version) {
      if (minor_version >= min_minor_version) { TRUE } else { FALSE }
    } else {
      FALSE
    }
  
  return(min_version_met)
}

#' @description
#' Compares two version strings, and returns `TRUE` if the first version string is greater than the
#' second version string
#' @export
`>.version_string` <- function(v1, v2) {

  major_version <- as.numeric(v1$components[1])
  minor_version <-  as.numeric(paste(v1$components[2:3], collapse = "."))
  
  min_major_version <- as.numeric(v2$components[1])
  min_minor_version <- as.numeric(paste(v2$components[2:3], collapse = "."))
  
  min_version_met <- 
    if (major_version > min_major_version) {
      TRUE
    } else if (major_version == min_major_version) {
      if (minor_version > min_minor_version) { TRUE } else { FALSE }
    } else {
      FALSE
    }
  
  return(min_version_met)
}

#' @description
#' Compares two version strings, and returns `TRUE` if the first version string is less than or
#' equal to the second version string
#' @export
`<=.version_string` <- function(v1, v2) {

  major_version <- as.numeric(v1$components[1])
  minor_version <-  as.numeric(paste(v1$components[2:3], collapse = "."))
  
  max_major_version <- as.numeric(v2$components[1])
  max_minor_version <- as.numeric(paste(v2$components[2:3], collapse = "."))
  
  max_version_met <- 
    if (major_version < max_major_version) {
      TRUE
    } else if (major_version == max_major_version) {
      if (minor_version <= max_minor_version) { TRUE } else { FALSE }
    } else {
      FALSE
    }
  
  return(max_version_met)
}

#' @description
#' Compares two version strings, and returns `TRUE` if the first version string is less than or
#' equal to the second version string
#' @export
`<.version_string` <- function(v1, v2) {

  major_version <- as.numeric(v1$components[1])
  minor_version <-  as.numeric(paste(v1$components[2:3], collapse = "."))
  
  max_major_version <- as.numeric(v2$components[1])
  max_minor_version <- as.numeric(paste(v2$components[2:3], collapse = "."))
  
  max_version_met <- 
    if (major_version < max_major_version) {
      TRUE
    } else if (major_version == max_major_version) {
      if (minor_version < max_minor_version) { TRUE } else { FALSE }
    } else {
      FALSE
    }
  
  return(max_version_met)
}

#' @title Check if the current version of R meets your criteria
#' @description
#' Checks whether the current version of R falls between the minimum and maximum versions specified 
#' 
#' @param minimum Scalar character vector describing the minimum version of R required. Should be
#'   specified in the Major.Minor.Patch format e.g., 3.6.3 or 4.4.1
#' @param maximum Scalar character vector describing the maximum version of R supported. Should be
#'   specified in the Major.Minor.Patch format e.g., 3.6.3 or 4.4.1. If no version is specified,
#'   this value is set to 9.9.9  (i.e., there is no maximum version)
#' @export
check_r_version <- function(minimum, maximum = NULL) {

  min_version_string <- version_string(minimum)
  
  if (is.null(maximum)) {
    maximum <- "9.9.9"
  }
  maximum_verion_string <- version_string(maximum)
  
  if (min_version_string > maximum_verion_string) {
    stop(
      paste0("Minimum required version (",
             minimum, 
             ") should not be higher than maximum version (",
             maximum,
             ")"
             )
      )
  }
  current_version_string <- version_string(paste(R.version$major, R.version$minor, sep = "."))
  
  min_version_met <- current_version_string >= min_version_string
  max_version_met <- current_version_string <= maximum_verion_string
  
  if (min_version_met && max_version_met) {
    
    # \u2714 is heavy check mark
    msg <- "\u2714 Your version of R is up to date!"
    
  } else if (!min_version_met) {
    
    suffix <- if (maximum == "9.9.9") {
      paste("version", minimum, "or higher")
    } else if (minimum == maximum) {
      paste("version", minimum)
    } else {
      paste("at least version", minimum, "but not higher than", maximum)
    }
    
    # \u2716 is heavy multiplication X
    msg <- paste("\u2716 Your version of R is incompatible; You should update to", suffix)
    
  } else if (!max_version_met) {
    
    msg <- paste("\u2716 The maximum supported version of R is", maximum)
    
  }
  
  cat(R.version.string, msg, sep="\n")

  return(invisible(min_version_met && max_version_met))
}

#' @title Set RStudio configuration options
#' @describeIn configure_rstudio Uses [rstudio.prefs::use_rstudio_prefs()] to set the following
#'   Rstudio configuration options from the Tools -> Global Options menu
#' 
#' ### Under General -> Basic
#' 
#' - Unchecks "Restore .RData into workspace at startup"
#' - Sets "Save workspace to .RData on exit" to "Never"
#' - Unchecks "Restore most recently opened project at startup"
#' - Unchecks "Restore previously open source documents at startup"
#' - Unchecks "Automatically notify me of updates"
#' 
#' ### Under R Markdown -> Basic
#' 
#' - Sets "Show output preview in" to "Viewer Pane"
#' - Unchecks "Show output inline for all R Markdown documents"
#' 
#' ### Under Code -> Display
#' 
#' - Unchecks "Enable preview of named and hexadecimal colors"
#' 
#' @importFrom rstudio.prefs use_rstudio_prefs
#' @export
configure_rstudio <- function() {

  use_rstudio_prefs(
    save_workspace = "never",
    load_workspace = FALSE,
    restore_last_project = FALSE,
    restore_source_documents = FALSE,
    check_for_updates = FALSE,
    color_preview = FALSE,
    rmd_viewer_type = "pane",
    rmd_chunk_output_inline = FALSE
  )
}

#' @describeIn configure_rstudio Checks whether the current RStudio configuration options match expected values, returns `TRUE` if all settings match exceptions.
#' @importFrom jsonlite fromJSON
#' @importFrom rstudio.prefs rstudio_config_path
#' @importFrom cli cli_alert_success cli_alert_danger
#' @export
check_rstudio_configuration <- function() {
  
  # retrieve rstudio configuration settings
  rstudio_config <- jsonlite::fromJSON(
    file.path(rstudio.prefs::rstudio_config_path(), "rstudio-prefs.json")
    )
  
  # compare current setting values against expected values
  options_set <- c(
    rstudio_config$save_workspace == "never",
    rstudio_config$load_workspace == FALSE,
    rstudio_config$restore_last_project == FALSE,
    rstudio_config$restore_source_documents == FALSE,
    rstudio_config$check_for_updates == FALSE,
    rstudio_config$color_preview == FALSE,
    rstudio_config$rmd_viewer_type == "pane",
    rstudio_config$rmd_chunk_output_inline == FALSE
    )
  
  if (all(options_set)) {
    cli::cli_alert_success("RStudio is correctly configured!")
  } else {
    cli::cli_alert_danger("RStudio settings have not been correctly configured.")
  }
  
  return(invisible(all(options_set)))
}

#' @title Check if the `tidyverse` is installed 
#' @description
#' Returns `TRUE` if the tidyverse is installed and (optionally) meets a minimum version
#' requirement. Also uses [cli::cli_alert()] to print out status messages to the user.
#' 
#' @importFrom utils installed.packages
#' @param minimum A scalar character vector describing a version of the tidyverse package e.g.,
#'   2.0.0 or 1.3.1
#' @export
#' @examples
#' \dontrun{
#' check_tidyverse("1.3.1")
#' }
check_tidyverse <- function(minimum) {
  
  has_tidyverse <- suppressPackageStartupMessages(requireNamespace("tidyverse"))

  if (has_tidyverse) {
    
    tidyverse_version <- installed.packages()[["tidyverse", "Version"]]
    
    if (tidyverse_version > minimum) {
      
      cli::cli_alert_success("{.pkg tidyverse} is installed and relatively up-to-date.")
      
    } else {
      
      cli::cli_alert_danger("{.pkg tidyverse} is installed but it is not up-to-date.
      Please update to version {minimum} or higher")
      
    }
    
    return(invisible(tidyverse_version > minimum))
  
  } else {
    
     cli::cli_alert_danger("{.pkg tidyverse} could not be loaded. Did you forget to install it?")
    
  }
  
  return(invisible(has_tidyverse))
}

#' @title Check if an Rstudio project is active
#' @description
#' Returns `TRUE` if an RStudio project can be found in the working directory (or above), and if it
#' is a sensible location for a project.
#' 
#' @importFrom usethis proj_path
#' @param denylist A regular expression identifying components of a file path that would indicate a problematic location for an RStudio project.
#' @export
check_project_environemnt <- function(denylist = "Desktop|Downloads") {
  
  project <- tryCatch(
    expr = {
      usethis::proj_path()
    },
    error = function(e) {
      FALSE
    }
  )
  
  if (!isFALSE(project)) {
    
    cli::cli_alert_success("Project found at: {.path {project}}")
    
    in_good_place <- !grepl(denylist, project, ignore.case = TRUE)
    
    if (in_good_place) {
      cli::cli_alert_success("Your project is in a good place.")
    } else {
      cli::cli_alert_warning(
      "Your project is not stored in a good place.
      Consider moving the project to your Documents folder."
      )
    }
    
    return(invisible(in_good_place))

  } else {
    
    cli::cli_alert_danger(
      "No project environment detected. Make sure you:\n
       1. Create and open an R project for SDS 100.
       2. Move your Quarto file into your project folder before rendering it
      "
    )
    return(invisible(!isFALSE(project)))
  }
}
