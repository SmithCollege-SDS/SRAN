#' @title Retrieve responses to the "Project Groups" Google form
#' @description
#' Students in SDS 100 self-organize into groups of three for the project, and inform the instructor
#' of their groups by filling out a Google form. The Google form the following questions:
#' 
#' - What is the name of their your group member?
#' - What is the Smith email address of your first group member?
#' - What is the name of your second group member?
#' - What is the Smith email address of your second group member?
#' - What is the name of your third group member?
#' - What is the Smith email address of your third group member?
#' - What is your group's name? (optional)
#' 
#' It also collects the time stamp of the form responses, and the email address of the respondent.
#' 
#' This form aggregates responses in a companion Google sheet. This function retrieves and "tidys" 
#' the responses from the companion Google sheet. If the group did not choose a name for themselves,
#' the group is assigned a unique name based on the group members initials.
#' 
#' @param gsheet_id Something that identifies a Google Sheet (e.g., the URL seen in the address bar
#'   of your browser after opening the sheet). See the documentation of[googlesheets4::read_sheet()]
#'   for more ways to identify Google Sheets.
#'
#' @return A tibble with the following columns:
#' 
#' - `timestamp`: A [POSIXct] object describing when the form responses were submitted
#' - `group_name`: The names of the groups
#' - `name`: The names of the individual students
#' - `email_address`: The Smith email addresses of individual students
#' 
#' @details
#' This function assumes the column names of the Google Sheet exactly match the text of the
#' questions in the description above.
#' 
#' However, it can handle an arbitrary number of group members, so long as the group members name
#' and email address are found in columns with names generalizing the pattern above (i.e., "What 
#' is the name of your n^th group member?" and "What is the Smith email address of your n^th group
#' member?").
#' 
#' @importFrom googlesheets4 read_sheet
#' @importFrom dplyr rename mutate filter group_by select ungroup coalesce recode
#' @importFrom tidyr pivot_longer
#' 
#' @export
get_project_group_form_responses <- function(gsheet_id) {
  
  groups <- googlesheets4::read_sheet(gsheet_id) |>
    dplyr::rename(
      timestamp = .data$Timestamp,
      group_name = .data$`What is your group's name? (optional)`
      ) |>
    tidyr::pivot_longer(
      cols = -c("timestamp", "group_name"),
      names_to = c(".value", "Member"),
      names_prefix = "What is the ",
      names_pattern = "(.+) of your (.+) group member\\?$"
    ) |>
    dplyr::rename(
      email_address = .data$`Smith email address`,
    ) |>
    dplyr::mutate(
      email_address = tolower(.data$email_address)
    ) |>
    dplyr::filter(!is.na(.data$name)) |>
    dplyr::group_by(.data$timestamp) |>
    dplyr::mutate(
      default_group_name = paste0(substr(.data$name, 1, 1), collapse = ""),
      group_name = dplyr::coalesce(.data$group_name, .data$default_group_name)
    ) |>
    dplyr::select(-.data$default_group_name, -.data$Member) |>
    dplyr::ungroup()
  
  groups <- deduplicate_group_names(groups)
  
  dupe_groups <- duplicated_groups(groups)
  
  if (length(dupe_groups > 0)) {

    x <- groups[groups$group_name %in% dupe_groups, ]
    x <- split(x$email_address, x$group_name)
    
    msg <- c(
      "The following groups appear to be duplicates of other groups",
      "",
      paste(names(x), sapply(x, paste0, collapse = ", "), sep = ": ")
      )
    
    cli::cli_warn(cli::col_red(msg))
  }
  
  dupe_students <- find_students_in_multiple_groups(groups[!groups$group_name %in% dupe_groups, ])
  
  if (length(dupe_students > 0)) {

    start <- if (length(dupe_groups > 0)) {
      "Excluding students in duplicate groups, "
    } else {
        ""
    }
    
    msg <- c(
      paste(start, "The following students appear in multiple groups:"),
      "",
      dupe_students
      )
    
    cli::cli_warn(cli::col_red(msg))
  } 
  
  return(groups)
}

#' @title Find problems with groups
#' @name group-problems
#' @description
#' Search for problems like duplicated groups, duplicated group names, or students in multiple
#' groups
NULL

#' @describeIn group-problems Ensures that group names are unique; if duplicated group names are
#'   found, a suffix (_1, _2, etc.) is added to the duplicates to make the names unique.
#'   
#' @param groups A data frame with `timestamp`, `group_name`, `name`, and `email` columns (like that
#'   returned from [get_project_group_form_responses()]).
#' 
#' @importFrom purrr imap
#' 
#' @export
deduplicate_group_names <- function(groups) {
  
  fix_names <- function(timestamps, group_names) {
      
    if (length(unique(timestamps)) != 1L) {
      group_names <- split(x = group_names, f = timestamps) |>
        unname() |>
        purrr::imap(paste, sep = "_") |>
        unlist()
     }
  
    return(group_names)
  }
    
  groups |>
    dplyr::group_by(.data$group_name) |>
    dplyr::mutate(
      group_name = fix_names(.data$timestamp, .data$group_name)
    ) |>
    ungroup()
}

#' @describeIn group-problems Return a data frame with the names and email address of students who
#'   are in multiple groups
#'
#' @export
find_students_in_multiple_groups <- function(groups) {
  
  groups$email_address[duplicated(groups$email_address)]

}

#' @title Check for issues with project groups
#' @describeIn group-problems Returns a character vector with names of groups that are duplicates
#'   of other groups
#' 
#' @importFrom purrr map
#' 
#' @export
duplicated_groups <- function(groups) {
  
  group_emails <- split(groups$email_address, f = groups$group_name) |>
    purrr::map(sort)
  
  dupe_groups <- names(group_emails)[duplicated(group_emails)]
  return(dupe_groups)
}

#' @describeIn group-problems Find students on the roster, but not in a groups.
#' 
#' @param roster a data frame representing the course roster. Is assumed to have at least a name and
#'   email address column. See [get_course_roster()] for a function that can retrieve a course
#'   roster from a Moodle page.
#' @param by Character vector describing the columns that can be used to match rows in the roster to rows in the project groups. Passed to [dplyr::anti_join()].
#' 
#' @importFrom dplyr anti_join
#' @export
find_students_without_groups <- function(roster, groups, by = "email_address") {
  
  dplyr::anti_join(
    roster,
    groups,
    by = by
  )

}

#' @describeIn group-problems Returns a data frame holding the just the names each group. Useful for generating a CSV of the can be uploaded to Moodle.
#' 
#' @param col <[`data-masked`][rlang::args_data_masking]> Name of the column holding group names
#' 
#' @importFrom dplyr distinct
#' @export
group_names <- function(groups, col = .data$group_name) {
  dplyr::distinct(groups, {{ col }})
}