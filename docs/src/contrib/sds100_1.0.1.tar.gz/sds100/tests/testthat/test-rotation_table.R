expected_table <- data.frame(
  `Art's Data` = c("Art I. Cuno", "Drag A. Pult", "Reg I. Gigas", "Art I. Cuno"),
  `Drag's Data` = c("Drag A. Pult", "Reg I. Gigas", "Art I. Cuno", "Drag A. Pult"),  
  `Reg's Data` = c("Reg I. Gigas", "Art I. Cuno", "Drag A. Pult", "Reg I. Gigas"),
  row.names = c("Phase 2", "Phase 3", "Phase 4", "Phase 5"),
  check.names = FALSE
)

random_order <- sample(1:3)

created_table <- create_rotation_table(
  group_members = c("Reg I. Gigas", "Art I. Cuno", "Drag A. Pult")[random_order],
  column_names =  c("Reg's Data", "Art's Data", "Drag's Data")[random_order],
  row_names = c("Phase 2", "Phase 3", "Phase 4", "Phase 5")
)

test_that("create_rotation_table works", {
  expect_equal(created_table, expected_table)
})

expected_table <- data.frame(
  `Art's Data` = c("Art I. Cuno", "Drag A. Pult", "Reg I. Gigas"),
  `Drag's Data` = c("Drag A. Pult", "Reg I. Gigas", "Art I. Cuno"),  
  `Reg's Data` = c("Reg I. Gigas", "Art I. Cuno", "Drag A. Pult"),
  row.names = c("Phase 2", "Phase 3", "Phase 4"),
  check.names = FALSE
)

random_order <- sample(1:3)

created_table <- create_rotation_table(
  group_members = c("Reg I. Gigas", "Art I. Cuno", "Drag A. Pult")[random_order],
  column_names =  c("Reg's Data", "Art's Data", "Drag's Data")[random_order],
  row_names = c("Phase 2", "Phase 3", "Phase 4")
)

test_that("create_rotation_table works", {
  expect_equal(created_table, expected_table)
})
